const CONFIG = {
  BASE_URL: 'https://story-api.dicoding.dev/v1',
};

export default CONFIG;

export const ACCESS_TOKEN_KEY = 'token';

// export const BASE_URL = 'https://story-api.dicoding.dev/v1';
